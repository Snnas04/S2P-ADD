create
    definer = root@`%` procedure dept_stats(IN id_departament int, OUT num_empleats int,
                                            OUT salari_mitja decimal(10, 2))
BEGIN SELECT COUNT(*) INTO num_empleats FROM EMP WHERE DEPT_NO = id_departament; IF num_empleats = 0 THEN SET salari_mitja = -1; SET num_empleats = 0; ELSE SELECT AVG(SALARI) INTO salari_mitja FROM EMP WHERE DEPT_NO = id_departament; END IF; END;

