create
    definer = root@`%` procedure DEPT(IN id_departament int, OUT num_empleats int, OUT salari_mitja decimal(10, 2))
BEGIN
    SELECT COUNT(*) INTO num_empleats FROM EMP WHERE DEPT_NO = id_departament;
    SELECT AVG(salari) INTO salari_mitja FROM EMP WHERE DEPT_NO = id_departament;
END;

