
import MenuPKG.Menu;
import MenuPKG.MenuOptions;
import MenuPKG.Option;

import java.sql.DriverManager;
import java.util.ArrayList;

public class Main {
    // user and password are created in the sql file
    private static final String url = "jdbc:mysql://localhost:3306/AM_BANK";
    private static final String user = "bank_user";
    private static final String password = "bank_password";

    public static void main(String[] args) {

        try (var conn = DriverManager.getConnection(url, user, password)) {
            var menuFunctions = new MenuOptions(conn);
            var options = new ArrayList<Option>();

            // READ
            options.add(new Option("Show clients", menuFunctions::showClients));
            options.add(new Option("Show employees", menuFunctions::showEmployees));
            options.add(new Option("Show transactions", menuFunctions::showClientTransactions));
            options.add(new Option("Show client appointments", menuFunctions::showClientAppointments));
            options.add(new Option("Show employee appointments", menuFunctions::showEmployeeAppointments));

            // ADD
            options.add(new Option("Create client", menuFunctions::addClient));
            options.add(new Option("Create employee", menuFunctions::addEmployee));
            options.add(new Option("Create appointment", menuFunctions::addAppointment));
            options.add(new Option("Do a transaction", menuFunctions::addTransaction));

            // DELETE
            options.add(new Option("Delete a client", menuFunctions::deleteClient));
            options.add(new Option("Delete an employee", menuFunctions::deleteEmployee));
            options.add(new Option("Delete an appointment", menuFunctions::deleteAppointment));

            // UPDATE
            options.add(new Option("Modify a client", menuFunctions::modifyClient));
            options.add(new Option("Modify a employee", menuFunctions::modifyEmployee));
            options.add(new Option("Modify a appointment", menuFunctions::modifyAppointment));

            // BATCH
            options.add(new Option("Execute batch query", menuFunctions::batchQuery));

            options.add(new Option("Export transactions to CSV", menuFunctions::toCSV));

            options.add(new Option("Exit", () -> System.exit(0)));


            var menu = new Menu("AM Bank", options);
            while (true) {
                menu.Show();
                menu.execute(menu.getInput());
            }
        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }
    }
}
