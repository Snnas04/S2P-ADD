package MenuPKG;

import java.util.List;
import java.util.Scanner;

public class Menu {
    private String Title;
    private List<Option> Options;

    public Menu(String title, List<Option> options) {
        this.Title = title;
        this.Options = options;
    }

    public void Show() {
        System.out.println("====================================");
        System.out.println(this.Title);
        for (int i = 0; i < this.Options.size(); i++) {
            System.out.println((i + 1) + ") " + this.Options.get(i));
        }
        System.out.println("====================================");
    }

    public void execute(int option) {
            Options.get(option - 1).exec();
    }

    public int getInput() {
        var scan = SingleScanner.getInstance();

        var option = scan.nextInt();

        if (option < 1 || option > Options.size()) {
            System.out.println("Enter a valid option");
            return getInput();
        }
        return option;
    }
}
