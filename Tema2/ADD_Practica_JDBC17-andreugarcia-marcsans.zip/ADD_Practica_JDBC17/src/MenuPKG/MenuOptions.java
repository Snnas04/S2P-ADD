package MenuPKG;

import MenuPKG.Menu;
import db.Create;
import db.Delete;
import db.Read;
import db.Update;

import java.sql.Connection;
import java.sql.Date;
import java.sql.SQLException;
import java.util.Scanner;

public class MenuOptions {
    private Create create;
    private Delete delete;
    private Update update;
    private Read read;

    private Scanner scan = SingleScanner.getInstance();

    public MenuOptions(Connection conn) {
        this.create = new Create();
        this.delete = new Delete();
        this.update = new Update();
        this.read = new Read();
    }

    public int getID() {
        System.out.println("Enter the ID: ");
        try {
            var res = scan.nextInt();
            return res;
        } catch (Exception e) {
            scan.next();
            System.out.println("Invalid ID format");
            return getID();
        }

    }

    private String getSqlDate(String msg) {

        System.out.println(msg);
        System.out.println("Enter the year: ");
        int year = scan.nextInt();
        System.out.println("Enter the month: ");
        int month = scan.nextInt();
        System.out.println("Enter the day: ");
        int day = scan.nextInt();
        scan.nextLine();
        try {
            return year + "-" + month + "-" + day + " 00:00:00";

        } catch (Exception e) {
            System.out.println("Invalid date format");
            return getSqlDate(msg);
        }
    }

    // Mostrar clients
    public void showClients() {
        try {
            read.showClients();
        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    // Mostrar Empleats
    public void showEmployees() {
        try {
            read.showEployees();
        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    // Mostrar Transaccions d'un client | Entrada / sortida
    public void showClientTransactions() {
        try {
            System.out.println("Enter 1 to show the income transactions");
            System.out.println("Enter any other number to show the output transactions");
            int option = scan.nextInt();
            read.showTransactions(getID(), option == 1);
        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    // Mostrar Cites d'un client en un rang de dates
    // TODO: finish
    public void showClientAppointments() {
        try {
            read.showClientAppointments(getID(), getSqlDate("Enter the FROM date"), getSqlDate("Enter the TO date"));
        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    // Mostrar Cites d'un empleat en un rang de dates
    public void showEmployeeAppointments() {
        try {
            read.showEmployeeAppointments(getID(), getSqlDate("Enter the FROM date"), getSqlDate("Enter the TO date"));
        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    // Afegir client
    public void addClient() {
        scan.nextLine();
        System.out.println("Enter the name: ");
        String name = scan.nextLine();
        System.out.println("Enter the lastname: ");
        String lastname = scan.nextLine();
        System.out.println("Enter the email: ");
        String email = scan.nextLine();
        System.out.println("Enter the phone: ");
        String phone = scan.nextLine();
        System.out.println("Enter the address: ");
        String address = scan.nextLine();
        System.out.println("Enter the seccondary address: ");
        String seccondary_address = scan.nextLine();
        System.out.println("Enter the money: ");
        double money = scan.nextDouble();
        scan.nextLine();
        try {
            create.createClient(name, lastname, email, phone, address, seccondary_address, money);
        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }
    }
    // Afegir empleat
    public void addEmployee() {
        scan.nextLine();
        System.out.println("Enter the name: ");
        String name = scan.nextLine();
        System.out.println("Enter the lastname: ");
        String lastname = scan.nextLine();
        System.out.println("Enter the email: ");
        String email = scan.nextLine();
        System.out.println("Enter the phone: ");
        String phone = scan.nextLine();
        System.out.println("Enter the address: ");
        String address = scan.nextLine();
        System.out.println("Enter the salary: ");
        double salary = scan.nextDouble();
        scan.nextLine();
        System.out.println("Enter the role: ");
        String role = scan.nextLine();
        try {
            create.createEmployee(name, lastname, email, phone, address, salary, role);
        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }
    }
    // Afegir cita
    public void addAppointment() {
        System.out.println("Enter the client ID: ");
        int client = scan.nextInt();
        scan.nextLine();
        System.out.println("Enter the employee ID: ");
        int employee = scan.nextInt();
        scan.nextLine();
        var date = getSqlDate("Enter the date: ");
        System.out.println("Enter the subject: ");
        String subject = scan.nextLine();
        try {
            create.createAppointment(client, employee, date, subject);
        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }
    }
    // Afegir transaccio
    public void addTransaction() {
        int clientID1 = getID();
        scan.nextLine();
        int clientID2 = getID();
        scan.nextLine();
        if (clientID1 == clientID2) {
            System.out.println("The client ID's must be different");
            return;
        }
        System.out.println("Enter the money: ");
        double money = scan.nextDouble();
        scan.nextLine();
        System.out.println("Enter the subject: ");
        String subject = scan.nextLine();
        System.out.println("Enter the additional info: ");
        String additional_info = scan.nextLine();

        try {
            create.createTransaction(clientID1, clientID2, money, subject, additional_info);
        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }
    }


    // Eliminar client
    public void deleteClient() {
        try {
            delete.deleteClient(getID());
        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }
    }
    // Eliminar empleat
    public void deleteEmployee() {
        try {
            delete.deleteEmployee(getID());
        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }
    }
    // Eliminar cita
    public void deleteAppointment() {
        try {
            delete.deleteAppointment(getID());
        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    // Modificar client
    public void modifyClient() {
        System.out.println("Enter the ID: ");
        int id = scan.nextInt();
        scan.nextLine();
        System.out.println("Enter the name: ");
        String name = scan.nextLine();
        System.out.println("Enter the lastname: ");
        String lastname = scan.nextLine();
        System.out.println("Enter the email: ");
        String email = scan.nextLine();
        System.out.println("Enter the phone: ");
        String phone = scan.nextLine();
        System.out.println("Enter the address: ");
        String address = scan.nextLine();
        System.out.println("Enter the seccondary address: ");
        String seccondary_address = scan.nextLine();
        System.out.println("Enter the money: ");
        double money = scan.nextDouble();
        scan.nextLine();
        update.modifyClient(id, name, lastname, email, phone, address, seccondary_address, money);
    }
    // Modificar empleat
    public void modifyEmployee() {
        System.out.println("Enter the ID: ");
        int id = scan.nextInt();
        scan.nextLine();
        System.out.println("Enter the name: ");
        String name = scan.nextLine();
        System.out.println("Enter the lastname: ");
        String lastname = scan.nextLine();
        System.out.println("Enter the email: ");
        String email = scan.nextLine();
        System.out.println("Enter the phone: ");
        String phone = scan.nextLine();
        System.out.println("Enter the address: ");
        String address = scan.nextLine();
        System.out.println("Enter the salary: ");
        double salary = scan.nextDouble();
        scan.nextLine();
        System.out.println("Enter the role: ");
        int role = scan.nextInt();
        update.modifyEmployee(id, name, lastname, email, phone, address, salary, role);
    }
    // Modificar cita
    public void modifyAppointment() {
        System.out.println("Enter the ID: ");
        int id = scan.nextInt();
        System.out.println("Enter the client ID: ");
        int client = scan.nextInt();
        scan.nextLine();
        System.out.println("Enter the employee ID: ");
        int employee = scan.nextInt();
        scan.nextLine();
        var date = getSqlDate("Enter the next camps for the date: ");
        System.out.println("Enter the subject: ");
        String subject = scan.nextLine();
        try {
            update.modifyAppointment(id, client, employee, date, subject);
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    // Executar batch query
    public void batchQuery() {
        try {
            update.batchQuery();
        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    public void toCSV() {
        try {
            read.toCSV("Transactions.csv");
            System.out.println("File Transactions.csv created");
        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }
    }
}
