package MenuPKG;

import java.util.Scanner;

public class SingleScanner {
    private static Scanner scan = new Scanner(System.in);

    public static Scanner getInstance() {
        return scan;
    }
}
