package MenuPKG;

public class Option {
    private String Text;
    private Runnable Action;

    public Option(String text, Runnable action) {
        this.Text = text;
        this.Action = action;
    }

    @Override
    public String toString() {
        return this.Text;
    }

    public void exec() {
        Action.run();
    }
}
