package db;

import java.io.FileWriter;
import java.io.IOException;
import java.sql.Connection;
import java.sql.Date;
import java.sql.SQLException;

public class Read extends BaseQuery{
    public void showTransactions(int clientID, boolean isPayer) {
        openConnection();
        try {
            var stm = conn.prepareCall("CALL show_transactions(?, ?)");
            stm.setInt(1, clientID);
            stm.setBoolean(2, isPayer);

            stm.execute();

            var resultSet = stm.getResultSet();
            Utils.print(resultSet);

        } catch (SQLException e) {
            throw new RuntimeException(e);
        } finally {
            closeConnection();
        }

    }

    public void showEmployeeAppointments(int employeeID, String startDate, String endDate) {
        openConnection();
        try {
            var stm = conn.prepareCall("CALL show_employee_appointments(?, ?, ?)");
            stm.setInt(1, employeeID);
            stm.setString(2, startDate);
            stm.setString(3, endDate);

            stm.execute();

            var resultSet = stm.getResultSet();
            Utils.print(resultSet);

        } catch (SQLException e) {
            throw new RuntimeException(e);
        } finally {
            closeConnection();
        }

    }

    public void showClientAppointments(int clientID, String startDate, String endDate) {
//        show_client_appointments
        openConnection();
        try {
            var stm = conn.prepareCall("CALL show_client_appointments(?, ?, ?)");
            stm.setInt(1, clientID);
            stm.setString(2, startDate);
            stm.setString(3, endDate);

            stm.execute();

            var resultSet = stm.getResultSet();
            Utils.print(resultSet);

        } catch (SQLException e) {
            throw new RuntimeException(e);
        } finally {
            closeConnection();
        }

    }

    public void showClients() {
        openConnection();
        try {
            var stm = conn.createStatement();
            var res = stm.executeQuery("SELECT id, name, lastname FROM CLIENT WHERE deleted = false");
            Utils.print(res);
        } catch (SQLException e) {
            throw new RuntimeException(e);
        } finally {
            closeConnection();
        }
    }


    public void showEployees() {
        openConnection();
        try {
            var stm = conn.createStatement();
            var res = stm.executeQuery("SELECT id, name, lastname FROM EMPLOYEE WHERE deleted = false");
            Utils.print(res);
        } catch (SQLException e) {
            throw new RuntimeException(e);
        } finally {
            closeConnection();
        }
    }

    public void toCSV(String filename) {
        openConnection();
        try {
            var stm = conn.createStatement();
            var res = stm.executeQuery("SELECT * FROM joinedTransaccions");
            var columns = res.getMetaData().getColumnCount();

            var fileds = new StringBuilder();
            for (int i = 1; i <= columns; i++) {
                fileds.append(res.getMetaData().getColumnLabel(i)+ ",");
            }

            var bilder = new StringBuilder();
            while (res.next()) {
                var row = new StringBuilder();
                for (int i = 0; i < columns; i++) {
                   row.append(res.getString(i + 1));
                   row.append(",");
                }
                bilder.append("\n");
                row.deleteCharAt(row.length() - 1);
                bilder.append(row);
            }
            try (var out = new FileWriter(filename)) {
                out.write(fileds.toString());
                out.write(bilder.toString());
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        } catch (IOException e) {
            throw new RuntimeException(e);
        } finally {
            closeConnection();
        }
    }
}
