package db;

import java.sql.Connection;
import java.sql.SQLException;

public class Delete extends BaseQuery {

    public void deleteClient(int client) throws SQLException {
        openConnection();
        var stm = conn.prepareCall("CALL delete_client(?)");

        stm.setInt(1, client);

        var result = stm.executeUpdate();

        closeConnection();
        if (result != 1) {
            System.out.println("El client no existeix");
        } else {
            System.out.println("S'ha eliminat " + result + " clients");
        }

    }

    public void deleteEmployee(int employee) throws SQLException {
        openConnection();
        var stm = conn.prepareCall("CALL delete_employee(?)");

        stm.setInt(1, employee);

        var result = stm.executeUpdate();

        closeConnection();
        if (result != 1) {
            System.out.println("L'empleat no existeix");
        } else {
            System.out.println("S'ha eliminat " + result + " empleats");
        }
    }

    public void deleteAppointment(int appointment) throws SQLException {
        openConnection();
        var stm = conn.prepareCall("CALL delete_appointment(?)");

        stm.setInt(1, appointment);

        var result = stm.executeUpdate();

        closeConnection();
        if (result == 0)
            System.out.println("La cita no existeix");
        else
            System.out.println("S'ha eliminat " + result + " cites");
    }
}
