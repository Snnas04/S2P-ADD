package db;
import java.sql.Connection;

public class BaseQuery {
    protected Connection conn;

    protected void openConnection() {
        Utils.openConnection(this);
    }

    protected void closeConnection() {
        Utils.closeConnection(this);
    }
}
