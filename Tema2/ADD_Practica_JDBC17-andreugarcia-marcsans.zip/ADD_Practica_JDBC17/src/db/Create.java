package db;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Date;
import java.sql.SQLException;

public class Create extends BaseQuery {

    public void createClient(String name, String lastname, String email, String phone , String address,
                             String seccondary_address, double money) throws SQLException {
        openConnection();
        var stm = conn.prepareCall("CALL create_client(?,?,?,?,?,?,?)");

        stm.setString(1, name);
        stm.setString(2, lastname);
        stm.setString(3, email);
        stm.setString(4, phone);
        stm.setString(5, address);
        stm.setString(6, seccondary_address);
        stm.setDouble(7, money);

        var result = stm.executeUpdate();
        closeConnection();


        System.out.println("S'ha afegit " + result + " clients");
    }

    public void createEmployee(String name, String lastname, String email, String phone, String address,
                               double salary, String role) throws SQLException {
        openConnection();
        var stm = conn.prepareCall("CALL create_employee(?,?,?,?,?,?,?)");

        stm.setString(1, name);
        stm.setString(2, lastname);
        stm.setString(3, email);
        stm.setString(4, phone);
        stm.setString(5, address);
        stm.setDouble(6, salary);
        stm.setString(7, role);

        var result = stm.executeUpdate();

        System.out.println("S'ha afegit " + result + " empleats");
        closeConnection();
    }

    public void createAppointment(int client, int employee, String date, String subject) throws SQLException {
        openConnection();
        var stm = conn.prepareCall("CALL create_appointment(?,?,?,?)");

        stm.setInt(1, client);
        stm.setInt(2, employee);
        stm.setString(3, date);
        stm.setString(4, subject);

        var result = stm.executeUpdate();

        closeConnection();
        System.out.println("S'ha afegit " + result + " cites");
    }

    public void createTransaction(int clientID1, int ClientID2, double money, String subject, String additional_info) {
        CallableStatement stm = null;
        openConnection();
        try {
            stm = conn.prepareCall("CALL create_transaction(?,?,?,?,?)");
            stm.setInt(1, clientID1);
            stm.setInt(2, ClientID2);
            stm.setDouble(3, money);
            stm.setString(4, subject);
            stm.setString(5, additional_info);

            var result = stm.executeUpdate();

            System.out.println("S'ha fet la transasccio");
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        closeConnection();

    }
}
