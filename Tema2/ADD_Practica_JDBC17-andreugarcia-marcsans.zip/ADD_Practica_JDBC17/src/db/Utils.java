package db;

import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;

public class Utils {
    private static final String url = "jdbc:mysql://localhost:3306/AM_BANK";
    private static final String user = "bank_user";
    private static final String password = "bank_password";

    public static void print(ResultSet rs) throws SQLException {
        var rsmd = rs.getMetaData();
        var columns = rsmd.getColumnCount();

        for (int i = 1; i <= columns; i++) {
            System.out.print(rsmd.getColumnLabel(i)+ "| ");
        }
        System.out.println();

        while (rs.next()) {
            for (int i = 1; i <= columns; i++) {
                System.out.print(rs.getObject(i) + " | ");
            }
            System.out.println();
        }
    }

    public static void openConnection(BaseQuery query) {
        try {
            query.conn = DriverManager.getConnection(url, user, password);
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    public static void closeConnection(BaseQuery query) {
        try {
            query.conn.close();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

}
