package db;

import java.sql.Connection;
import java.sql.SQLException;

public class Update extends BaseQuery {
    // Represents a monthly batch query (with the menu can be executed at any time)
    public void batchQuery() {
        openConnection();
        var sql1 = "UPDATE CLIENT SET money = money * 1.01 WHERE created_at < DATE_SUB(NOW(), INTERVAL 5 YEAR)";
        var sql2 = "UPDATE CLIENT SET money = 0 WHERE deleted = true";
        var sql3 = "DELETE FROM APPOINTMENT A  WHERE ( SELECT deleted FROM CLIENT WHERE A.client_id = id)";
        var sql4 = "DELETE FROM APPOINTMENT A  WHERE ( SELECT deleted FROM EMPLOYEE WHERE A.employee_id = id)";

        try {
            var stm = conn.createStatement();
            stm.addBatch(sql1);
            stm.addBatch(sql2);
            stm.addBatch(sql3);
            stm.addBatch(sql4);
            var results = stm.executeBatch();
            for (int i = 0; i < results.length; i++) {
                System.out.println("Query " + i + " affected " + results[i] + " rows");
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        } finally {
            closeConnection();
        }
    }

    // Modify a client
    public void modifyClient(int id, String name, String lastname, String email, String phone, String address,
            String seccondary_address, double money) {
        openConnection();

        try {
            var stm = conn.prepareCall("CALL modify_client(?,?,?,?,?,?,?,?)");

            stm.setInt(1, id);
            stm.setString(2, name);
            stm.setString(3, lastname);
            stm.setString(4, email);
            stm.setString(5, phone);
            stm.setString(6, address);
            stm.setString(7, seccondary_address);
            stm.setDouble(8, money);

            var result = stm.executeUpdate();

            System.out.println("S'ha modificat " + result + " clients");
        } catch (SQLException e) {
            throw new RuntimeException(e);
        } finally {
            closeConnection();
        }
    }

    // Modify a employee
    public void modifyEmployee(int id, String name, String lastname, String email, String phone, String address,
            double salary, int role) {
        openConnection();

        try {
            var stm = conn.prepareCall("CALL modify_employee(?,?,?,?,?,?,?,?)");

            stm.setInt(1, id);
            stm.setString(2, name);
            stm.setString(3, lastname);
            stm.setString(4, email);
            stm.setString(5, phone);
            stm.setString(6, address);
            stm.setDouble(7, salary);
            stm.setInt(8, role);

            var result = stm.executeUpdate();

            System.out.println("S'ha modificat " + result + " empleats");
        } catch (SQLException e) {
            throw new RuntimeException(e);
        } finally {
            closeConnection();
        }
    }

    // Modify a appointment
    public void modifyAppointment(int id, int client, int employee, String date, String subject) throws SQLException {
        openConnection();
        try {
            var stm = conn.prepareCall("CALL modify_appointment(?,?,?,?,?)");

            stm.setInt(1, id);
            stm.setInt(2, client);
            stm.setInt(3, employee);
            stm.setString(4, date);
            stm.setString(5, subject);

            var result = stm.executeUpdate();

            System.out.println("S'ha modificat " + result + " cites");
        } catch (SQLException e) {
            throw new RuntimeException(e);
        } finally {
            closeConnection();
        }
    }
}
