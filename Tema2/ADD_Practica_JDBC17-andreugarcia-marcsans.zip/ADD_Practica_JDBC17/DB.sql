-- BANK DATABASE
DROP DATABASE IF EXISTS AM_BANK;
CREATE DATABASE AM_BANK;
USE AM_BANK;

/***********************
*    TABLE CREATION    *
***********************/

-- CLIENTS Table
CREATE TABLE CLIENT
(
    id                 INT            NOT NULL AUTO_INCREMENT,
    name               VARCHAR(50)    NOT NULL,
    lastname           VARCHAR(50)    NOT NULL,
    email              VARCHAR(50)    NOT NULL,
    phone              VARCHAR(20)    NOT NULL, -- There are a lot of different phone number formats, so I'm just going to use VARCHAR
    address            VARCHAR(100)   NOT NULL,
    seccondary_address VARCHAR(100),
    money              DECIMAL(10, 2) NOT NULL,
    deleted   BOOLEAN      DEFAULT FALSE,

    created_at         TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at         TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,

    PRIMARY KEY (id)
);
-- TRANSACTIONS Table
CREATE TABLE TRANSACTION
(
    id              INT            NOT NULL AUTO_INCREMENT UNIQUE,
    payer           INT            NOT NULL,
    beneficiary     INT            NOT NULL,
    amount          DECIMAL(10, 2) NOT NULL,
    subject         VARCHAR(50)    NOT NULL,
    additional_info VARCHAR(50),

    created_at      TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at      TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,

    PRIMARY KEY (id, payer, beneficiary),
    FOREIGN KEY (payer) REFERENCES CLIENT (id),
    FOREIGN KEY (beneficiary) REFERENCES CLIENT (id)
);

-- employee_role Table
CREATE TABLE ROLES
(
    role    INT          NOT NULL,
    name    VARCHAR(50)  NOT NULL,

    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,

    PRIMARY KEY (role)
);

-- EMPLOYEE Table
CREATE TABLE EMPLOYEE
(
    id         INT          NOT NULL AUTO_INCREMENT,
    name       VARCHAR(50)  NOT NULL,
    lastname   VARCHAR(50)  NOT NULL,
    email      VARCHAR(50)  NOT NULL,
    phone      VARCHAR(20)  NOT NULL, -- There are a lot of different phone number formats, so I'm just going to use VARCHAR
    address    VARCHAR(100) NOT NULL,
    salary     INT          NOT NULL,
    role_id      INT          NOT NULL,
    deleted   BOOLEAN      DEFAULT FALSE,

    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,

    PRIMARY KEY (id),
    FOREIGN KEY (role_id) REFERENCES ROLES (role)
);

-- appointment Table
CREATE TABLE APPOINTMENT
(
    id          INT      NOT NULL AUTO_INCREMENT,
    client_id   INT      NOT NULL,
    employee_id INT      NOT NULL,
    date        DATETIME NOT NULL,
    subject     VARCHAR(200),

    created_at  TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at  TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,

    PRIMARY KEY (id),
    FOREIGN KEY (client_id) REFERENCES CLIENT (id),
    FOREIGN KEY (employee_id) REFERENCES EMPLOYEE (id)
);



/***********************
*    TABLE INSERTION   *
************************/

-- CLIENT Table
INSERT INTO CLIENT (name, lastname, email, phone, address, seccondary_address, money)
VALUES ('John', 'Doe', 'john.doe@email.com', '123-456-7890', '123 Main St', NULL, 1000),
       ('Jane', 'Smith', 'jane.smith@email.com', '555-555-5555', '456 Elm St', 'Apt 2B', 5000),
       ('Bob', 'Johnson', 'bob.johnson@email.com', '777-777-7777', '789 Oak St', NULL, 750),
       ('Sara', 'Wilson', 'sara.wilson@email.com', '888-888-8888', '987 Pine St', NULL, 2000),
       ('Mike', 'Adams', 'mike.adams@email.com', '999-999-9999', '456 Birch St', 'Suite 101', 3000),
       ('Lisa', 'Taylor', 'lisa.taylor@email.com', '123-123-1234', '321 Maple St', 'Apt 3C', 1500),
       ('Mark', 'Brown', 'mark.brown@email.com', '456-789-0123', '111 Cedar St', 'Unit 5', 4000),
       ('Emily', 'Hall', 'emily.hall@email.com', '321-654-9870', '654 Oak St', NULL, 900),
       ('David', 'Miller', 'david.miller@email.com', '222-333-4444', '567 Elm St', 'Suite 202', 6000),
       ('Grace', 'Davis', 'grace.davis@email.com', '111-222-3333', '789 Pine St', 'Apt 1A', 2500),
       ('Richard', 'Garcia', 'richard.garcia@email.com', '777-888-9999', '555 Birch St', NULL, 1800),
       ('Linda', 'Martinez', 'linda.martinez@email.com', '666-555-4444', '333 Cedar St', 'Unit 10', 3500),
       ('Paul', 'Young', 'paul.young@email.com', '444-666-8888', '222 Maple St', NULL, 1200),
       ('Karen', 'Clark', 'karen.clark@email.com', '333-222-1111', '999 Oak St', 'Apt 4B', 2700),
       ('Steven', 'Harris', 'steven.harris@email.com', '555-777-9999', '444 Elm St', 'Suite 303', 7000),
       ('Catherine', 'Turner', 'catherine.turner@email.com', '666-999-3333', '888 Pine St', 'Apt 2C', 1300),
       ('Michael', 'King', 'michael.king@email.com', '777-555-3333', '222 Birch St', NULL, 3200),
       ('Jennifer', 'Parker', 'jennifer.parker@email.com', '888-111-9999', '555 Cedar St', 'Unit 8', 4200),
       ('Sarah', 'Adams', 'sarah.adams@email.com', '333-777-1111', '777 Maple St', NULL, 900),
       ('Robert', 'White', 'robert.white@email.com', '222-666-4444', '111 Oak St', 'Apt 3A', 5500);

-- TRANSACTION Table
INSERT INTO TRANSACTION (payer, beneficiary, amount, subject, additional_info)
VALUES (1, 2, 500, 'Payment 1', 'Invoice #12345'),
       (2, 3, 750, 'Payment 2', 'Invoice #23456'),
       (3, 4, 1000, 'Payment 3', NULL),
       (4, 5, 250, 'Payment 4', 'Invoice #45678'),
       (5, 6, 800, 'Payment 5', 'Invoice #56789'),
       (6, 7, 300, 'Payment 6', 'Invoice #67890'),
       (7, 8, 600, 'Payment 7', 'Invoice #78901'),
       (8, 9, 900, 'Payment 8', 'Invoice #89012'),
       (9, 10, 150, 'Payment 9', NULL),
       (10, 11, 400, 'Payment 10', 'Invoice #01234'),
       (11, 12, 700, 'Payment 11', 'Invoice #12345'),
       (12, 13, 450, 'Payment 12', 'Invoice #23456'),
       (13, 14, 300, 'Payment 13', 'Invoice #34567'),
       (14, 15, 800, 'Payment 14', 'Invoice #45678'),
       (15, 16, 250, 'Payment 15', 'Invoice #56789'),
       (16, 17, 550, 'Payment 16', 'Invoice #67890'),
       (17, 18, 950, 'Payment 17', 'Invoice #78901'),
       (18, 19, 200, 'Payment 18', NULL),
       (19, 20, 600, 'Payment 19', 'Invoice #90123'),
       (20, 1, 400, 'Payment 20', 'Invoice #01234');

-- ROLES Table
INSERT INTO ROLES (role, name)
VALUES (1, 'Employee'),
       (2, 'Manager'),
       (3, 'Admin');

-- EMPLOYEE Table
INSERT INTO EMPLOYEE (name, lastname, email, phone, address, salary, role_id)
VALUES ('John', 'Doe', 'john.doe@example.com', '555-123-4567', '123 Main St', 50000, 1),
       ('Jane', 'Smith', 'jane.smith@example.com', '555-987-6543', '456 Elm St', 60000, 1),
       ('Robert', 'Johnson', 'robert.j@example.com', '555-789-1234', '789 Oak St', 55000, 1),
       ('Sarah', 'Williams', 'sarah.w@example.com', '555-321-8765', '567 Maple St', 65000, 1),
       ('David', 'Wilson', 'david.w@example.com', '555-876-5432', '890 Birch St', 58000, 1),
       ('Emily', 'Davis', 'emily.d@example.com', '555-234-5678', '234 Pine St', 52000, 1),
       ('Michael', 'Brown', 'michael.b@example.com', '555-345-6789', '456 Cedar St', 57000, 1),
       ('Jennifer', 'Martinez', 'jennifer.m@example.com', '555-987-6543', '123 Oak St', 60000, 1),
       ('William', 'Harris', 'william.h@example.com', '555-654-7890', '789 Elm St', 54000, 1),
       ('Jessica', 'Jones', 'jessica.j@example.com', '555-234-5678', '456 Birch St', 62000, 1),
       ('Daniel', 'Taylor', 'daniel.t@example.com', '555-987-6543', '345 Maple St', 55000, 1),
       ('Mary', 'Johnson', 'mary.j@example.com', '555-789-1234', '890 Cedar St', 58000, 1),
       ('James', 'Lee', 'james.l@example.com', '555-456-7890', '234 Oak St', 53000, 1),
       ('Olivia', 'Miller', 'olivia.m@example.com', '555-234-5678', '567 Elm St', 64000, 1),
       ('John', 'Anderson', 'john.a@example.com', '555-987-6543', '123 Birch St', 57000, 1),
       ('Sophia', 'Garcia', 'sophia.g@example.com', '555-876-5432', '890 Maple St', 56000, 1),
       ('Liam', 'Smith', 'liam.s@example.com', '555-234-5678', '456 Cedar St', 59000, 1),
       ('Ava', 'Clark', 'ava.c@example.com', '555-987-6543', '234 Elm St', 57000, 1),
       ('Ethan', 'Hernandez', 'ethan.h@example.com', '555-876-5432', '789 Pine St', 54000, 1),
       ('Isabella', 'Young', 'isabella.y@example.com', '555-789-1234', '567 Oak St', 61000, 1);


-- APPOINTMENT Table
INSERT INTO APPOINTMENT (client_id, employee_id, date, subject)
VALUES (1, 1, '2023-11-07 09:00:00', 'Meeting with Client 1'),
       (2, 2, '2023-11-07 10:00:00', 'Meeting with Client 2'),
       (3, 3, '2023-11-07 11:00:00', 'Meeting with Client 3'),
       (4, 4, '2023-11-07 12:00:00', 'Meeting with Client 4'),
       (5, 5, '2023-11-07 13:00:00', 'Meeting with Client 5'),
       (6, 6, '2023-11-07 14:00:00', 'Meeting with Client 6'),
       (7, 7, '2023-11-07 15:00:00', 'Meeting with Client 7'),
       (8, 8, '2023-11-07 16:00:00', 'Meeting with Client 8'),
       (9, 9, '2023-11-07 17:00:00', 'Meeting with Client 9'),
       (10, 10, '2023-11-07 18:00:00', 'Meeting with Client 10'),
       (11, 11, '2023-11-07 19:00:00', 'Meeting with Client 11'),
       (12, 12, '2023-11-07 10:30:00', 'Meeting with Client 12'),
       (13, 13, '2023-11-07 11:30:00', 'Meeting with Client 13'),
       (14, 14, '2023-11-07 12:30:00', 'Meeting with Client 14'),
       (15, 15, '2023-11-07 13:30:00', 'Meeting with Client 15'),
       (16, 16, '2023-11-07 14:30:00', 'Meeting with Client 16'),
       (17, 17, '2023-11-07 15:30:00', 'Meeting with Client 17'),
       (18, 18, '2023-11-07 16:30:00', 'Meeting with Client 18'),
       (19, 19, '2023-11-07 17:30:00', 'Meeting with Client 19'),
       (20, 20, '2023-11-07 18:30:00', NULL);

/***********************
*     CREATE USER      *
************************/
DROP USER IF EXISTS 'bank_user'@'%';
CREATE USER 'bank_user'@'%' IDENTIFIED BY 'bank_password';
GRANT ALL PRIVILEGES ON AM_BANK.* TO 'bank_user'@'%';


/***********************
*      PROCEDURES      *
************************/
-- TODO: TEST ALL

/***********************
*        MOSTRAR       *
************************/

-- MOSTRAR Transaccions
CREATE view joinedTransaccions as
SELECT T.id,
       CP.name           as 'Payer',
       CB.name           as 'Beneficiary',
       T.amount,
       T.subject,
       T.additional_info as 'Additional Info'
FROM TRANSACTION T
         JOIN CLIENT CB ON T.beneficiary = CB.id
         JOIN CLIENT CP ON T.payer = CP.id;

-- MOSTRAR TRANSACCIONS DE UN CLIENT
DROP PROCEDURE IF Exists show_transactions;
CREATE PROCEDURE show_transactions(IN client_id INT, IN is_payer BOOLEAN)
BEGIN
    SELECT T.id,
           CP.name           as 'Payer',
           CB.name           as 'Beneficiary',
           T.amount,
           T.subject,
           T.additional_info as 'Additional Info'
    FROM TRANSACTION T
             JOIN CLIENT CB ON T.beneficiary = CB.id
             JOIN CLIENT CP ON T.payer = CP.id
    WHERE IF(is_payer, payer, beneficiary) = client_id;
END;



-- MOSTRAR CITES D'UN CLIENT (INTERVAL DE TEMPS)
DROP PROCEDURE IF Exists show_client_appointments;
CREATE PROCEDURE show_client_appointments(IN client_id INT, IN start_date DATETIME, IN end_date DATETIME)
BEGIN
    SELECT A.id, E.name as 'Employee', A.date, A.subject
    FROM APPOINTMENT A
             JOIN EMPLOYEE E ON A.employee_id = E.id
    WHERE A.client_id = client_id
      AND A.date BETWEEN IFNULL(start_date, '1000-01-01') AND IFNULL(end_date, curdate());
END;

call show_employee_appointments(1, '2023-11-07', '2023-11-07');

-- MOSTRAR CITES D'UN EMPLEAT (INTERVAL DE TEMPS)
DROP PROCEDURE IF Exists show_employee_appointments;
CREATE PROCEDURE show_employee_appointments(IN client_id INT, IN start_date DATETIME, IN end_date DATETIME)
BEGIN
    SELECT A.id, E.name as 'Client', A.date, A.subject
    FROM APPOINTMENT A
             JOIN CLIENT E ON A.employee_id = E.id
    WHERE A.client_id = client_id
      AND A.date BETWEEN IFNULL(start_date, '1000-01-01') AND IFNULL(end_date, curdate());
END;

/***********************
*         CREAR        *
************************/


-- CREAR CLIENT
CREATE PROCEDURE create_client(IN name VARCHAR(50), IN lastname VARCHAR(50), IN email VARCHAR(50), IN phone VARCHAR(20),
                               IN address VARCHAR(100), IN seccondary_address VARCHAR(100), IN money DECIMAL(10, 2))
BEGIN
    INSERT INTO CLIENT (name, lastname, email, phone, address, seccondary_address, money)
    VALUES (name, lastname, email, phone, address, seccondary_address, money);
END;

-- CREAR EMPLEAT
CREATE PROCEDURE create_employee(IN name VARCHAR(50), IN lastname VARCHAR(50), IN email VARCHAR(50), IN phone VARCHAR(20),
                                 IN address VARCHAR(100), IN salary INT, IN role_name VARCHAR(50))
BEGIN
    DECLARE role INT;
    SELECT R.role INTO role FROM ROLES R WHERE R.name = role_name;

    IF role IS NULL THEN
        INSERT INTO ROLES (name) VALUES (role_name);
        SELECT R.role INTO role FROM ROLES R WHERE R.name = role_name;
    END IF;

    INSERT INTO EMPLOYEE (name, lastname, email, phone, address, salary, role_id)
    VALUES (name, lastname, email, phone, address, salary, role);
END;

-- CREAR APPOINTMENT
DROP PROCEDURE IF Exists create_appointment;
CREATE PROCEDURE create_appointment(IN client_id INT, IN employee_id INT, IN date DATETIME, IN subject VARCHAR(200))
BEGIN
    IF checkAppointmentDate(employee_id, date) = FALSE THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'This employee already has an appointment at this time';
    END IF;
    INSERT INTO APPOINTMENT (client_id, employee_id, date, subject)
    VALUES (client_id, employee_id, date, subject);
END;


/***********************
*      MODIFIACR       *
************************/

-- MODIFICAR EMPLEAT
DROP PROCEDURE IF Exists modify_employee;
CREATE PROCEDURE modify_employee(IN emp_id INT, IN name VARCHAR(50), IN lastname VARCHAR(50), IN email VARCHAR(50),
                                 IN phone VARCHAR(20),
                                 IN address VARCHAR(100), IN salary INT, IN role_id INT)
BEGIN
    UPDATE EMPLOYEE E
    SET E.name     = IFNULL(name, E.name),
        E.lastname = IFNULL(lastname, E.lastname),
        E.email    = IFNULL(email, E.email),
        E.phone    = IFNULL(phone, E.phone),
        E.address  = IFNULL(address, E.address),
        E.salary   = IFNULL(salary, E.salary),
        E.role_id  = IFNULL(role_id, E.role_id)
    WHERE E.id = emp_id;

    SELECT * FROM EMPLOYEE WHERE id = emp_id;
END;


-- MODIFICAR CLIENT
CREATE PROCEDURE modify_client(IN client_id INT, IN name VARCHAR(50), IN lastname VARCHAR(50), IN email VARCHAR(50),
                               IN phone VARCHAR(20),
                               IN address VARCHAR(100), IN seccondary_address VARCHAR(100), IN money DECIMAL(10, 2))
BEGIN
    UPDATE CLIENT C
    SET C.name               = IFNULL(name, C.name),
        C.lastname           = IFNULL(lastname, C.lastname),
        C.email              = IFNULL(email, C.email),
        C.phone              = IFNULL(phone, C.phone),
        C.address            = IFNULL(address, C.address),
        C.seccondary_address = IFNULL(seccondary_address, C.seccondary_address),
        C.money              = IFNULL(money, C.money)
    WHERE C.id = client_id;

    SELECT * FROM CLIENT WHERE id = client_id;
END;

-- MODIFICAR CITA
DROP PROCEDURE IF Exists modify_appointment;
CREATE PROCEDURE modify_appointment(IN appointment_id INT, IN client_id INT, IN employee_id INT, IN date DATETIME,
                                    IN subject VARCHAR(200))
BEGIN
    IF checkAppointmentDate(employee_id, date) = FALSE THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'This employee already has an appointment at this time';
    END IF;
    UPDATE APPOINTMENT A
    SET A.client_id   = IFNULL(client_id, A.client_id),
        A.employee_id = IFNULL(employee_id, A.employee_id),
        A.date        = IFNULL(date, A.date),
        A.subject     = IFNULL(subject, A.subject)
    WHERE A.id = appointment_id;

    SELECT * FROM APPOINTMENT WHERE id = appointment_id;
END;

--  CALL modify_appointment(1, 1, 1, '2023-11-07 09:00:01', 'Meeting with Client 1'); ERROR OK

-- Checks that the  employee doesn't have an appointment in a range of 30 minutes before and after the given date

CREATE FUNCTION checkAppointmentDate(employee INT, date DATETIME)
RETURNS BOOLEAN
READS SQL DATA
BEGIN
    DECLARE result BOOLEAN;
    SET result = TRUE;
    IF (SELECT COUNT(*) FROM APPOINTMENT A WHERE A.employee_id = employee AND A.date BETWEEN date - INTERVAL 30 MINUTE AND date + INTERVAL 30 MINUTE) > 0 THEN
        SET result = FALSE;
    END IF;
    RETURN result;
END;

/***********************
*        ELIMINAR      *
************************/
-- ELIMINAR EMPLEAT
DROP PROCEDURE IF Exists delete_employee;
CREATE PROCEDURE delete_employee(IN emp_id INT)
BEGIN
    UPDATE EMPLOYEE E
    SET E.deleted = TRUE
    WHERE E.id = emp_id AND E.deleted = FALSE;
END;


-- ELIMINAR CLIENT
DROP PROCEDURE IF Exists delete_client;
CREATE PROCEDURE delete_client(IN client_id INT)
BEGIN
    -- DECLARE initialDeletedValue BOOLEAN;
    -- Retrieve the initial value of deleted before update
    -- SELECT deleted INTO initialDeletedValue FROM CLIENT WHERE id = client_id;

    -- Update the deleted flag
    UPDATE CLIENT SET deleted = TRUE WHERE id = client_id AND deleted = false;

    -- Set the OUT parameter to the initial value of deleted
    --  SET wasDeleted = initialDeletedValue;
END;


-- ELIMINAR CITA
DROP PROCEDURE IF Exists delete_appointment;
CREATE PROCEDURE delete_appointment(IN appointment_id INT)
BEGIN
    DELETE FROM APPOINTMENT WHERE id = appointment_id;
END;

-- CREAR TRANSACCIO entre dos clients
DROP PROCEDURE IF Exists create_transaction;
CREATE PROCEDURE create_transaction(IN payer INT, IN beneficiary INT, IN amount DECIMAL(10, 2), IN subject VARCHAR(50),
                                    IN additional_info VARCHAR(50))
BEGIN
    IF (payer = beneficiary) THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Payer and beneficiary cannot be the same';
    END IF;
    BEGIN
        DECLARE EXIT HANDLER FOR SQLEXCEPTION
            BEGIN
                ROLLBACK;
                SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Error creating transaction';
            END;
        START TRANSACTION;

        UPDATE CLIENT C
        SET C.money = C.money - amount
        WHERE C.id = payer;
        UPDATE CLIENT C
        SET C.money = C.money + amount
        WHERE C.id = beneficiary;
        INSERT INTO TRANSACTION (payer, beneficiary, amount, subject, additional_info)
        VALUES (payer, beneficiary, amount, subject, additional_info);

        COMMIT;
    END;
END;

-- BATCH: Afegir les nomines de una en una i després pagarles totes de cop (from java)
