create definer = root@`%` view oferta_teatral as
select `O`.`titol`                               AS `Títol`,
       `P`.`nom`                                 AS `Director`,
       `G`.`genere`                              AS `Gènere`,
       `O`.`tipo`                                AS `Tipus`,
       group_concat(`T`.`ciutat` separator ', ') AS `Ciutats`,
       `O`.`cost`                                AS `Cost`
from (((((`Teatre`.`Obra` `O` join `Teatre`.`Director` `D`
          on ((`O`.`idDirector` = `D`.`DNI`))) join `Teatre`.`Persona` `P`
         on ((`D`.`DNI` = `P`.`DNI`))) join `Teatre`.`Generes` `G`
        on ((`O`.`idGenere` = `G`.`ID`))) join `Teatre`.`Funcio` `F`
       on ((`O`.`titol` = `F`.`Obra_Titol`))) join `Teatre`.`Teatre` `T` on ((`F`.`Teatre_ID` = `T`.`ID`)))
where (year(`F`.`datetime`) = year(curdate()))
group by `O`.`titol`
order by `O`.`titol`;

