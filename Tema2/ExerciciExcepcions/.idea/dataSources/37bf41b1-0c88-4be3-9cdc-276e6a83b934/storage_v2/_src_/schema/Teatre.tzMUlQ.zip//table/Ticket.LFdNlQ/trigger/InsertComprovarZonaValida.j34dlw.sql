create definer = root@`%` trigger InsertComprovarZonaValida
    before insert
    on Ticket
    for each row
BEGIN
  IF NOT esUnaZonaValida(NEW.idZona, NEW.Teatre_ID) THEN
      SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Invalid Zone';
  END IF;
END;

