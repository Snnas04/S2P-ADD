create
    definer = root@`%` function esUnaZonaValida(idZone int, Teatre_ID int) returns tinyint(1) reads sql data
BEGIN
  RETURN idZone IN (SELECT idZona FROM Teatre_Zona WHERE idTeatre = Teatre_ID);
END;

