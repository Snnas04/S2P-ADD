create definer = root@`%` event copiesNotReturned on schedule
    every '1' DAY
        starts '2023-05-10 06:00:00'
    on completion preserve
    disable
    do
    begin
    declare llibre int;
    declare resultat text default '';
    declare fin boolean default false;

    declare myCursor cursor for select COPY_CODE from BORROWS where RETURN_DATE is null and DEAD_DATE < now();
    declare continue handler for not found set fin = true;

    open myCursor;
    bucle: loop
        fetch myCursor into llibre;
        if fin = true then
            leave bucle;
        end if;
        insert into not_returned values (null, llibre);
    end loop;
    close myCursor;
end;

