create definer = root@`%` event move_historic_partits on schedule
    every '1' MONTH
        starts '2023-05-10 16:00:25'
    on completion preserve
    enable
    do
    BEGIN
        INSERT INTO historic_partits (elocal, evisitant, resultat, data, arbit)
        SELECT elocal, evisitant, resultat, data, arbit FROM partits
        WHERE data < DATE_FORMAT(NOW(), '%Y-%m-01');

        DELETE FROM partits
        WHERE data < DATE_FORMAT(NOW(), '%Y-%m-01');
    END;

