create definer = root@`%` trigger inseri_client
    after insert
    on clientes
    for each row
begin 
        if exists(select * from statistics where dia = curdate()) then
            update statistics set num_clients = num_clients + 1 where dia = curdate();
        else
            insert into statistics values (null, curdate(),1);
        end if;
    end;

