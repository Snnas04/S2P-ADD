create definer = root@`%` trigger eliminar_compte
    after delete
    on cuentas
    for each row
    insert into auditoria values (null, OLD.saldo, OLD.cod_cuenta, current_user(), now());

