create definer = root@`%` trigger llibreInsert
    after insert
    on LLIBRES
    for each row
BEGIN
    INSERT INTO llibresLog (book_code, operation, new_title, new_isbn, user, daatetime) VALUES
        (NEW.ID_LLIB, 'Insert', NEW.TITOL, NEW.ISBN, CURRENT_USER(), NOW());
END;

