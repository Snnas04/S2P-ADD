create
    definer = root@`%` procedure flightFrom(IN searchLocation varchar(30))
BEGIN
    DECLARE output VARCHAR(1000) DEFAULT CONCAT('From ', searchLocation);
    DECLARE departureDate DATE;
    DECLARE flightNumber CHAR(5);
    DECLARE departureTimeHM VARCHAR(255);
    DECLARE airport CHAR(3);
    DECLARE fin BOOLEAN DEFAULT FALSE;
    DECLARE flight CURSOR FOR SELECT DATE(departure_time) as dateA,
                                     flight_number,
                                     TIME_FORMAT(departure_time, '%H:%i'),
                                     arrival_airport
                              FROM FLIGHTS
                                       JOIN AIRPORTS D on D.id_airport = FLIGHTS.departure_airport
                              WHERE D.location = searchLocation
                              ORDER BY dateA;
    declare continue handler for not found set fin = true;
    OPEN flight;
    WHILE fin = FALSE
        DO
            fetch flight into departureDate,flightNumber,departureTimeHM, airport;
            SET output =
                    CONCAT(
                            output, '\n', '------>',
                            'on ', departureDate,
                            ' flight nr. ', flightNumber,
                            ' to ', airport,
                            ' at ', departureTimeHM
                        );
        end while;
    CLOSE flight;
    SELECT output;
END;

