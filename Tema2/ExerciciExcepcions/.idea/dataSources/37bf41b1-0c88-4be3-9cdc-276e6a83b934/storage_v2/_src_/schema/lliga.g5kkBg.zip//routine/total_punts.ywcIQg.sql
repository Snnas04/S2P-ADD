create
    definer = root@`%` function total_punts(resultat varchar(7)) returns int reads sql data
BEGIN
    DECLARE punts_local INT;
    DECLARE punts_visitant INT;
    SET punts_local = SUBSTRING_INDEX(resultat, '-', 1);
    SET punts_visitant = SUBSTRING_INDEX(resultat, '-', -1);
    RETURN punts_local + punts_visitant;
END;

