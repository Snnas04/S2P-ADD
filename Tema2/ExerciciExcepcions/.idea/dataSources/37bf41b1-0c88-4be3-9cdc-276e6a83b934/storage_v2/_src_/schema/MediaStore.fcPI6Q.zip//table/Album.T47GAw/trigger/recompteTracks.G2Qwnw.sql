create definer = root@`%` trigger recompteTracks
    after insert
    on Album
    for each row
begin
        if (numTracks < (select count(TrackId) from Track where Track.AlbumId = AlbumId)) then
            update Album
            set numTracks = numTracks + (select count(TrackId) from Track group by AlbumId);
        end if;
    end;

