create
    definer = root@`%` function Funcio_Rol(actor_name varchar(40), play_title varchar(100)) returns varchar(50)
    reads sql data
BEGIN
    DECLARE role VARCHAR(50);

    SELECT rol INTO role
    FROM Obra_Actor AS OA
             JOIN Actors AS A ON OA.actor_dni = A.DNI
             JOIN Persona AS P ON A.DNI = P.DNI
    WHERE P.nom = actor_name
      AND OA.titol = play_title;

    IF role IS NULL THEN
        SET role = '***';
    END IF;

    RETURN role;
END;

