create
    definer = root@`%` procedure ordenant(IN num1 int, IN num2 int, IN num3 int) reads sql data
begin
    declare ordenat boolean default true;
    declare temp int default 0;
    while ordenat do
            if num1 < num2 then
                set temp = num1;
                set num1 = num2;
                set num2 = temp;
            end if;

            if num2 < num3 then
                set temp = num2;
                set num2 = num3;
                set num3 = temp;
            end if;
            if num1 > num2 and num2 > num3 then
                set ordenat = false;
            end if;
        end while;

    select concat(num3, ' > ', num2, ' > ', num1);
end;

