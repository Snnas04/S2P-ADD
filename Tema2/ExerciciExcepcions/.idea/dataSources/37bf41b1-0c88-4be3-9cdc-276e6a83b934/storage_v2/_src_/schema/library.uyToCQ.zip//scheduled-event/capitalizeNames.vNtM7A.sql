create definer = root@`%` event capitalizeNames on schedule
    at '2023-05-10 14:21:23'
    on completion preserve
    disable
    do
    begin
    update MEMBERS set NAME = upper(NAME);
    update MEMBERS set SURNAMES = upper(SURNAMES);
end;

