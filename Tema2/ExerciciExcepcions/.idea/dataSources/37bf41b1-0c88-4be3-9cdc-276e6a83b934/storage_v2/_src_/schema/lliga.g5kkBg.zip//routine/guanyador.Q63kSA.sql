create
    definer = root@`%` function guanyador(resultat varchar(8)) returns tinyint reads sql data
begin
	declare x int;
    declare y int;
    declare z tinyint;
    set x = substring_index(resultat,'-',1);
    set y = substring_index(resultat,'-',-1);
    
    if x > y then
		set z = 0;
	elseif y > x then
		set z = 1;
	end if;
	return z;
end;

