create definer = root@`%` view Top5Madrid as
select `JARDINERIA`.`cm`.`NomClient` AS `NomClient`, `c`.`CodiPostal` AS `CodiPostal`, `c`.`Telefon` AS `Telefon`
from (`JARDINERIA`.`CompteComandesMadrid` `cm` join `JARDINERIA`.`Clients` `c`
      on ((`c`.`NomClient` = `JARDINERIA`.`cm`.`NomClient`)))
order by `JARDINERIA`.`cm`.`NumeroDeComandes` desc, `JARDINERIA`.`cm`.`NomClient`
limit 5;

grant select (NomClient, CodiPostal), select (Telefon) on table Top5Madrid to X;

