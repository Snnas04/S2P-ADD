create definer = root@`%` trigger validarCanvisFactures
    before update
    on Invoice
    for each row
begin
        if (month(OLD.InvoiceDate) < month(curdate()) or year(OLD.InvoiceDate) < year(curdate())) then
            SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Ha passat mes d un mes';
        end if;
    end;

