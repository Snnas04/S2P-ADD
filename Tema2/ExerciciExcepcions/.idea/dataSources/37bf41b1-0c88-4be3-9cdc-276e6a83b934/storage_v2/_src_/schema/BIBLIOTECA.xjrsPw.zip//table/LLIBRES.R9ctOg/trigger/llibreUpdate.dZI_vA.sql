create definer = root@`%` trigger llibreUpdate
    after update
    on LLIBRES
    for each row
BEGIN
    INSERT INTO llibresLog VALUES
        (NEW.ID_LLIB, 'Update', NEW.TITOL, OLD.TITOL, NEW.ISBN, OLD.ISBN, CURRENT_USER(), NOW());
END;

