create
    definer = root@`%` procedure getFlightsFrom(IN place varchar(30))
BEGIN
    SELECT DATE(departure_time) AS 'DATE',
           id_flight AS 'FLIGHT',
           D.location AS 'FROM',
           arrival_airport AS 'TO',
           departure_time AS 'TIME DEPARTURE',
           arrival_time AS 'TIME ARRIVAL',
           DATE_FORMAT(SEC_TO_TIME(TIMESTAMPDIFF(SECOND, arrival_time, departure_time)), '%H:%i') as DURATION
    FROM FLIGHTS
             JOIN CREWS C on C.id_crew = FLIGHTS.id_copilot
             JOIN CREWS P on P.id_crew = FLIGHTS.id_pilot
             JOIN AIRPORTS A on A.id_airport = FLIGHTS.arrival_airport
             JOIN AIRPORTS D on D.id_airport = FLIGHTS.departure_airport
    WHERE D.location = place;
END;

