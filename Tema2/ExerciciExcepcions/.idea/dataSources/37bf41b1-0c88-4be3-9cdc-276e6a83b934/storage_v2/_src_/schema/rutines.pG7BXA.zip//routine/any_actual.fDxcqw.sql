create
    definer = root@`%` function any_actual() returns int reads sql data
    return year(curdate());

