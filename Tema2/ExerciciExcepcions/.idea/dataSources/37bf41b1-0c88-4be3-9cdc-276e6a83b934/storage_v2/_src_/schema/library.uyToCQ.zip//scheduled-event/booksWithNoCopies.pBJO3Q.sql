create definer = root@`%` event booksWithNoCopies on schedule
    at '2023-05-10 23:00:00'
    on completion preserve
    disable
    do
    begin
    truncate table no_copies;
    insert into no_copies (bookCode, bookTitle)
    select book_code, title from BOOKS where book_code not in (select book_code from COPIES);
end;

