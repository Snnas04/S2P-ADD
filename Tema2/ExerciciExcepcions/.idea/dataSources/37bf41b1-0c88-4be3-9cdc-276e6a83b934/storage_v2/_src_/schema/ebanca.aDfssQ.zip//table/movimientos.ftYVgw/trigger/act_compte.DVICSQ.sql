create definer = root@`%` trigger act_compte
    after insert
    on movimientos
    for each row
    update cuentas set saldo = saldo + NEW.cantidad where cod_cuenta = new.cod_cuenta;

