create
    definer = root@`%` function mediaInfo(cuantsBytes int, medidaType int) returns varchar(13) reads sql data
begin
        if (medidaType = 3) then
            if (cuantsBytes < 300000000) then
                return 'Video lleuger';
            elseif (cuantsBytes > 300000000 and cuantsBytes < 600000000) then
                return 'Video';
            elseif (cuantsBytes > 600000000) then
                return 'Video pesat';
            end if;
        else
            if (cuantsBytes < 17000000) then
                return 'Audio lleuger';
            elseif (cuantsBytes > 17000000 and cuantsBytes < 35000000) then
                return 'Audio';
            elseif (cuantsBytes > 35000000) then
                return 'Audio pesat';
            end if;
        end if;
    end;

