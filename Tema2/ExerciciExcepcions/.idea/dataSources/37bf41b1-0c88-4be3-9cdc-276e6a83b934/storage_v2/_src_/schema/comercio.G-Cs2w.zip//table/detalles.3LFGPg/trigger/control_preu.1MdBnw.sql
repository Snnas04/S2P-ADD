create definer = root@`%` trigger control_preu
    before update
    on detalles
    for each row
    if NEW.precio < 0 then
        set NEW.precio = 0;
    elseif NEW.precio > 200 then
        set NEW.precio = 200;
    end if;

