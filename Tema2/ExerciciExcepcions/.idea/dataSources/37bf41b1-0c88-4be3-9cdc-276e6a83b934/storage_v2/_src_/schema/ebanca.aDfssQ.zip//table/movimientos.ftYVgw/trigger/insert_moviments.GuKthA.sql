create definer = root@`%` trigger insert_moviments
    after insert
    on movimientos
    for each row
    set @sum = @sum + NEW.cantidad;

