create
    definer = root@`%` procedure PARTICIPANTS(IN play_title varchar(100), IN participant_type char)
BEGIN
    IF participant_type = 'a' THEN
        SELECT P.nom, TIMESTAMPDIFF(YEAR, P.data_neixament, CURDATE()) AS age, OA.paper, Funcio_Rol(P.nom, O.titol) AS role
        FROM Persona AS P
                 JOIN Actors AS A ON P.DNI = A.DNI
                 JOIN Obra_Actor AS OA ON A.DNI = OA.actor_dni
                 JOIN Obra AS O ON OA.titol = O.titol
        WHERE O.titol = play_title
        ORDER BY CASE
                     WHEN Funcio_Rol(P.nom, O.titol) = 'PRINCIPAL' THEN 1
                     WHEN Funcio_Rol(P.nom, O.titol) = 'SECUNDARI' THEN 2
                     WHEN Funcio_Rol(P.nom, O.titol) = 'EXTRA' THEN 3
                     ELSE 4
                     END, P.nom;

    ELSEIF participant_type = 't' THEN
        SELECT P2.nom, TIMESTAMPDIFF(YEAR, P2.data_neixament, CURDATE()) AS age, OPT.tasca
        FROM Persona AS P2 
                 JOIN PersonalTecnic AS PT ON P2.DNI = PT.DNI
                 JOIN Obra_PersonalTecnic AS OPT ON PT.DNI = OPT.personal_DNI
                 JOIN Obra AS O2 ON OPT.titol = O2.titol
        WHERE O2.titol = play_title
        ORDER BY P2.nom;

    END IF;
END;

