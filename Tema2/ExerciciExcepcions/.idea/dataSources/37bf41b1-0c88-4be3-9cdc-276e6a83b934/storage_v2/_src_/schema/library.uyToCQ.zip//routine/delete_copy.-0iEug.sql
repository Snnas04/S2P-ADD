create
    definer = root@`%` procedure delete_copy(IN cc int, OUT ncopies tinyint)
inici: begin
	declare bc char(4);
    
    if exists (select * from BORROWS where COPY_CODE = cc and RETURN_DATE is null) then
		select 'Aquesta copia esta en presete. No es pot eliminar';
        leave inici;
	end if;
	select BOOK_CODE into bc from COPIES where COPY_CODE = cc;
    
	delete from BORROWS where COPY_CODE = cc;    
	delete from COPIES where COPY_CODE = cc;
    
    if bc is null then
		select 'Aquesta copia no existeix';
	end if;
    
    if bc is not null then
		delete from COPIES where COPY_CODE = cc;
        select count(*) into ncopies from COPIES where BOOK_CODE = bc;
        
        if ncopies = 0 then
			delete from GENREBOOK where BOOK_CODE = bc;
			delete from BOOKS where BOOK_CODE = bc;
		end if;
	end if;
end;

