create definer = root@`%` trigger llibreDelete
    before delete
    on LLIBRES
    for each row
BEGIN
    INSERT INTO llibresLog VALUES
        (OLD.ID_LLIB, 'Delete', null, old.TITOL, null, old.ISBN, CURRENT_USER(), NOW());
END;

