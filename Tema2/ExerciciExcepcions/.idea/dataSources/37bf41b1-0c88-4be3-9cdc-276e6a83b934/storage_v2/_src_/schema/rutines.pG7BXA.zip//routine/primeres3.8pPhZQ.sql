create
    definer = root@`%` procedure primeres3(IN cadena varchar(30))
BEGIN
	DECLARE resultat VARCHAR(3);

	set resultat = upper(SUBSTRING('marc', 1, 3));

	SELECT resultat;
END;

