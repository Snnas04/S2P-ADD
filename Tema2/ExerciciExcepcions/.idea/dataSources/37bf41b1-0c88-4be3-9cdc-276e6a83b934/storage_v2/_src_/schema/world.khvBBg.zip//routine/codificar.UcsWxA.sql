create
    definer = root@`%` procedure codificar()
begin
	declare vID int;
    declare vCountryCode char(3);
    declare darrerPais char(3) default '';
    declare cont int;
	declare final boolean default false;
    
	declare myCursor cursor for 
		select id, countryCode from world.city order by CountryCode, name;
	declare continue handler for not found set final = true;
    
    open myCursor;
    
    bucle: loop
		fetch myCursor into vID, vCountryCode;
		if final then
			leave bucle;
        end if;
        
        if vCountryCode != darrerPais then
			set cont = 0;
        end if;
        
        set cont = cont + 1;
        update city set newCode = concat(vCountryCode, lpad(cont, 3, '0')) where ID = vID;
        
        set darrerPais = vCountryCode;
    end loop;
    
    close myCursor;
end;

