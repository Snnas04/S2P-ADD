create
    definer = root@`%` function Funcio_Millor() returns varchar(100) reads sql data
BEGIN
    DECLARE best_play_list VARCHAR(100);
    DECLARE max_total DECIMAL(10,2);

    SELECT MAX(total) INTO max_total
    FROM (
             SELECT SUM(preu) AS total
             FROM Ticket
             GROUP BY Obra_Titol
         ) AS total_price_table;

    SELECT GROUP_CONCAT(Obra_Titol) INTO best_play_list
    FROM (
             SELECT Obra_Titol, SUM(preu) AS total
             FROM Ticket
             GROUP BY Obra_Titol
             HAVING total = max_total
         ) AS max_price_table;

    RETURN best_play_list;
END;

