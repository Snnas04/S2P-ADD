create definer = root@`%` trigger insert_fac
    after insert
    on facturas
    for each row
    set @total = @total + 1;

