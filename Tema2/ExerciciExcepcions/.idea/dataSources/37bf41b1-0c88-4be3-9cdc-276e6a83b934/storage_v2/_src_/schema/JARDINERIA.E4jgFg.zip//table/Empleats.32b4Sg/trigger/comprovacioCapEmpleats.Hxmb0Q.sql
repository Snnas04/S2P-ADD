create definer = root@`%` trigger comprovacioCapEmpleats
    before insert
    on Empleats
    for each row
BEGIN
    IF ((SELECT count(*) from Empleats WHERE CodiCap = NEW.CodiCap) >= 10) THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'This have 10 or more employees!!';
    end if;
end;

