create
    definer = root@`%` procedure GENERES()
BEGIN
    SELECT G.genere, COUNT(O.idGenere) AS obra_count
    FROM Generes AS G
             LEFT JOIN Obra AS O ON G.ID = O.idGenere
    GROUP BY G.genere
    ORDER BY obra_count DESC;
END;

