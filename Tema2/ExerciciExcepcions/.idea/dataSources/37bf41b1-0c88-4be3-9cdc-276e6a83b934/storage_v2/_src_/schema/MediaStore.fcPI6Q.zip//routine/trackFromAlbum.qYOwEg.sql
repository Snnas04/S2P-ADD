create
    definer = root@`%` procedure trackFromAlbum(IN disco varchar(255), OUT artista varchar(100),
                                                OUT cancons varchar(255)) reads sql data
begin
    declare discoID int;

    select AlbumId into discoID from Album where Title = disco;

    select A.Name into artista from Album
        join Artist A on Album.ArtistId = A.ArtistId
        where AlbumId = discoID;

    select concat(Name, '(', time_format(Milliseconds, '%m:%S') , ')') into cancons
        from Track;
end;

