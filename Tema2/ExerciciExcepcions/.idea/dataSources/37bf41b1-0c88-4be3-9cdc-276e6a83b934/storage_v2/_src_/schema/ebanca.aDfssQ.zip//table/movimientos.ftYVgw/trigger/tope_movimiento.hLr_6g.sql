create definer = root@`%` trigger tope_movimiento
    before insert
    on movimientos
    for each row
    if NEW.cantidad > 100000 then
            set NEW.cantidad = 100000;
        end if;

