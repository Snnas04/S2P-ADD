create
    definer = root@`%` procedure tablecounter(IN db varchar(20)) reads sql data
begin
    declare fin boolean default false;
    declare tab varchar(45);
    declare myCursor cursor for select TABLE_NAME from information_schema.TABLES where TABLE_SCHEMA = db;
    declare continue handler for not found set fin = true;

    open myCursor;
    bucle: loop
        fetch myCursor into tab;
        if fin = true then
            leave bucle;
        end if;
        set @result = concat('SELECT COUNT(*) ',tab,' FROM ', db, '.', tab, ';');
        PREPARE prepared_stmt FROM @result;
        EXECUTE prepared_stmt;
    end loop;
    close myCursor;
end;

