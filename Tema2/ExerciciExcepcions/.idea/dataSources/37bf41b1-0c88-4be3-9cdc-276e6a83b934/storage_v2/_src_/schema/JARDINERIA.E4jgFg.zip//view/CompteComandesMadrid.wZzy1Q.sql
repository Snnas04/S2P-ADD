create definer = root@`%` view CompteComandesMadrid as
select `JARDINERIA`.`Clients`.`NomClient`                                                   AS `NomClient`,
       `JARDINERIA`.`Clients`.`NomContacte`                                                 AS `NomContacte`,
       (select count(`JARDINERIA`.`Comandes`.`CodiComanda`)
        from `JARDINERIA`.`Comandes`
        where (`JARDINERIA`.`Clients`.`CodiClient` = `JARDINERIA`.`Comandes`.`CodiClient`)) AS `NumeroDeComandes`
from `JARDINERIA`.`Clients`
where (`JARDINERIA`.`Clients`.`Regio` = 'Madrid')
order by `JARDINERIA`.`Clients`.`NomClient`;

