create definer = root@`%` trigger afegir_ticket
    before insert
    on tickets
    for each row
begin
        declare complet boolean;

        select tickets_for_sale = tickets_sold into complet from shows where id = NEW.show_id;
        if complet then
            signal sqlstate '45000' set message_text = 'Tickets sold out!';
        else
            update shows set tickets_sold = tickets_sold + 1 where id = NEW.show_id;
        end if;
    end;

