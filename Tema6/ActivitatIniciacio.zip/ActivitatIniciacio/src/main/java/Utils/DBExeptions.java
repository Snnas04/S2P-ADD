package Utils;

public class DBExeptions extends Exception {
    public DBExeptions(String message) {
        super(message);
    }
}
