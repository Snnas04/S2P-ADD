import org.snmp4j.CommunityTarget;
import org.snmp4j.PDU;
import org.snmp4j.Snmp;
import org.snmp4j.TransportMapping;
import org.snmp4j.event.ResponseEvent;
import org.snmp4j.mp.SnmpConstants;
import org.snmp4j.smi.*;
import java.io.IOException;

public class SNMPExample {
    public static void main(String[] args) {
        try {
            // Configuración del target
            Address targetAddress = GenericAddress.parse("udp:192.168.1.1/161");
            CommunityTarget target = new CommunityTarget();
            target.setCommunity(new OctetString("public"));
            target.setAddress(targetAddress);
            target.setRetries(2);
            target.setTimeout(1500);
            target.setVersion(SnmpConstants.version2c);

            // Creación del SNMP
            TransportMapping<? extends Address> transport = new DefaultUdpTransportMapping();
            Snmp snmp = new Snmp(transport);
            transport.listen();

            // Creación de la PDU
            PDU pdu = new PDU();
            pdu.add(new VariableBinding(new OID("1.3.6.1.2.1.1.1.0"))); // Ejemplo de OID

            // Envío de la PDU
            ResponseEvent response = snmp.send(pdu, target);

            // Procesamiento de la respuesta
            if (response != null && response.getResponse() != null) {
                System.out.println("Response received. Value: " + response.getResponse().get(0).getVariable());
            } else {
                System.out.println("No response received.");
            }

            // Cierre del SNMP
            snmp.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
