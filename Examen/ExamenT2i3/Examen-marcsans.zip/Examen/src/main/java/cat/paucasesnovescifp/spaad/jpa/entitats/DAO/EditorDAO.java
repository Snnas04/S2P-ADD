package cat.paucasesnovescifp.spaad.jpa.entitats.DAO;

import cat.paucasesnovescifp.spaad.jpa.entitats.Editor;

import java.util.List;

public interface EditorDAO {
    List<Editor> findAll();
}
