package cat.paucasesnovescifp.spaad.jpa.entitats.DAO;


public interface AutorDAO {
    void findByID(int idAutor);
}
