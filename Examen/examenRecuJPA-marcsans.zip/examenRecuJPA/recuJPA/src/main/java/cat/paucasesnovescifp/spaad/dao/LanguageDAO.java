package cat.paucasesnovescifp.spaad.dao;

public interface LanguageDAO {
    boolean deleteById(int id);
}
